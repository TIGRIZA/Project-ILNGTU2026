a = "hello world"
b = "8 burgers"

print(a.capitalize())
print(b.capitalize())
